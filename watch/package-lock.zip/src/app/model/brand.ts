export interface Brand {
  id?: number;
  origin?:string;
  tag?:string;
  deleteStatus?:number;
}
