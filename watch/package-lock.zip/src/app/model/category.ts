export interface Category {
  id?:number;
  type?:string;
  deleteStatus?:number;
}
